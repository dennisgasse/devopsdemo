# Azure_Demo = Master branche
Test deployment Axians CS Datacenter Team meeting 13-09-2023
Created by: Dennis Gasse

## AxiansDemo

Create Storage acoount

### Github Action
Basis en main tamplate: vanuit hier worden de verschillende Bicep module gestart.

Binnen deze demo starten we Module SA-delpoy welke een Storage Account aanmaakt binnen een gegeven demo subscription

## Project info
Binnen de folder Project bevinden zich tekening van deployment = project documentatie

![Vwan Any to Any connectivity overview](image/StorageAccount.PNG)

--- Voorbeeld deploy direct to Azure ---

<a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2FAzure%2Fazure-quickstart-templates%2Fmaster%2Fquickstarts%2Fmicrosoft.storage%2Fstorage-account-create%2Fazuredeploy.json" target="_blank">
  <img src="https://aka.ms/deploytoazurebutton"/>
</a>
